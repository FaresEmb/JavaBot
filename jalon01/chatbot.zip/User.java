
public class User {
		String name;


		User(String name) {
			this.name = name;
		}
    String description() {
			return "Bonjour";
		}
		String getName() {
			return this.name;
		}

}
